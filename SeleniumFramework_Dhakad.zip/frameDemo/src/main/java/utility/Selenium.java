
package utility;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import static org.testng.Assert.fail;

import org.testng.Reporter;
import org.testng.SkipException;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;


/**
 * Main driver class for setting up Web UI testing, running the webpages, and tearing down testing.

 * @author ShailendraDhakad
 */
public class Selenium {


	public static boolean isElePresent = false;
	public static boolean sElementChecked=false;
	public static WebDriver driver;
	public static WebElement wElement;
	public static WebDriverWait waiting;
	public static String sTestCaseName;

	public static WebDriver openApplication(String sBaseURL, String sBrowserType)
	{
		System.setProperty("webdriver.gecko.driver","drivers//geckodriver.exe");
		if (sBrowserType.equalsIgnoreCase("firefox"))
		{
			Log.info("Firefox browser");
			
		}
		else if (sBrowserType.equalsIgnoreCase("IE"))
		{
			Log.info("IE browser");
			
		}
		else if (sBrowserType.equalsIgnoreCase("chrome"))
		{
			Log.info("Chrome browser");
			System.setProperty("webdriver.chrome.driver","drivers//chromedriver_latest.exe");

			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			driver.manage().window().maximize();
		}

		driver.get(sBaseURL);
		return driver;
	}  

	/*
	 * #######################################################################################
	 * ##                                Test Controls                                      ##
	 * #######################################################################################
	 */


	/**
	 * Skip the running test which is currently being executed.&nbsp; 
	 * Avoids a failing a test if not testable.
	 * 
	 * <p>Log level: WARN
	 * 
	 * @see #skipTest(String, boolean, Exception)
	 * @param message the message to pass to the logger
	 * @throws Exception 
	 */
	public static void skipTest(String message)  {
		skipTest(message,true, null);
	}

	/**
	 * Skip the running test which is currently being executed.&nbsp; 
	 * Avoids a failing a test if not testable.
	 * 
	 * <p>If {@code takeScreenCapture} is {@code true}, than captures the
	 * current window and saves to a PNG file.
	 * 
	 * <p>Log level: WARN
	 * 
	 * @see #skipTest(String, boolean, Exception)
	 * @param message the message to pass to the logger
	 * @param takeScreenCapture set to {@code true} if want to take a screen 
	 *                          capture, otherwise {@code false}
	 * @throws Exception 
	 */
	public static void skipTest(String message, boolean takeScreenCapture) {
		skipTest(message, takeScreenCapture, null);
	}

	/**
	 * Skip the running test which is currently being executed.&nbsp; 
	 * Avoids a failing a test if not testable.
	 * 
	 * <p>If {@code takeScreenCapture} is {@code true}, than captures the
	 * current window and saves to a PNG file.
	 * 
	 * <p>Log level: WARN
	 * 
	 * @param message the message to pass to the logger
	 * @param takeScreenCapture set to {@code true} if want to take a screen 
	 *                          capture, otherwise {@code false}
	 * @param exception exception to log, otherwise {@code null}
	 * @throws Exception 
	 */
	public static void skipTest(String message,boolean takeScreenCapture, Exception exception)  {
		String link;
		try{
			if (takeScreenCapture) {
				link = Utils.takeScreenshot(driver, sTestCaseName);
				if (link == null)
					link = "";
			}
			if (exception == null)
				Log.warn(message);
			else
				Log.warn(message + exception);
			throw new SkipException(message);
		}
		catch(Exception e){
			Log.error("Exception:"+e.getMessage());
		}
	}

	/**
	 * Fails the running test with a specific error message.
	 * 
	 * <p>Log level: ERROR
	 * 
	 * @see #failTest(String, boolean, Exception)
	 * @param message   the error message to display when failing the test
	 * @throws Exception 
	 */
	public static void failTest(String message)  {
		failTest(message,true, null);
	}

	/**
	 * Fails the running test with a specific error message.
	 * 
	 * <p>If {@code takeScreenCapture} is {@code true}, than captures the
	 * current window and saves to a PNG file.
	 * 
	 * <p>Log level: ERROR
	 * 
	 * @see #failTest(String, boolean, Exception) 
	 * @param message   the error message to display when failing the test
	 * @param takeScreenCapture set to {@code true} if want to take a screen 
	 *                          capture, otherwise {@code false}
	 * @throws Exception 
	 */
	public static void failTest(String message,boolean takeScreenCapture) {
		failTest(message, takeScreenCapture, null);
	}

	/**
	 * Fails the running test with a specific error message.
	 * 
	 * <p>If {@code takeScreenCapture} is {@code true}, than captures the
	 * current window and saves to a PNG file.
	 * 
	 * <p>Log level: ERROR
	 * 
	 * @param message   the error message to display when failing the test
	 * @param takeScreenCapture set to {@code true} if want to take a screen 
	 *                          capture, otherwise {@code false}
	 * @param exception exception to log, otherwise {@code null}
	 * @throws Exception 
	 */
	public static void failTest(String message, boolean takeScreenCapture, Exception exception)  {
		String link = "";
		try{
			if (takeScreenCapture) {
				link = Utils.takeScreenshot(driver, sTestCaseName);
				if (link == null)
					link = "";
				else
					AdvanceReporting.getTest().addScreenCaptureFromPath(link);
			}
			if (exception == null){
				Log.error(message + link);
				AdvanceReporting.getTest().fail(message);//.log(LogStatus.ERROR, message);
			}
			else{
				Log.error(message + link + exception);
				AdvanceReporting.getTest().fail(message + "Exception: " + exception, MediaEntityBuilder.createScreenCaptureFromPath(link).build());

			}	
			fail(message);
		}
		catch(Exception e)
		{
			Log.error("Excpetion" + e.getMessage());
		}
	}


	/*

    	SoftAssert
	 */
	public static void failTestbySoftAssert(String message, boolean takeScreenCapture, Exception exception)  {
		String link = "";
		try{
			if (takeScreenCapture) {
				link = Utils.takeScreenshot(driver, sTestCaseName);
				if (link == null)
					link = "";
				else
					AdvanceReporting.getTest().addScreenCaptureFromPath(link);
			}
			if (exception == null){
				Log.error(message + link);
				AdvanceReporting.getTest().fail(message);//.log(LogStatus.ERROR, message);


			}
			else{
				Log.error(message + link + exception);
				AdvanceReporting.getTest().fail(message + "Exception: " + exception, MediaEntityBuilder.createScreenCaptureFromPath(link).build());

			}	

		}
		catch(Exception e)
		{
			Log.error("Excpetion" + e.getMessage());
		}
	}

	/**
	 * Passes the running test with a specific message.
	 * 
	 * <p>Log level: INFO
	 * 
	 * @see #passTest(String, boolean)
	 * @param message   the message to display when passing the test
	 * @throws Exception 
	 */
	public static void passTest(String message)  {
		passTest(message, false);
	}

	/**
	 * Passes the running test with a specific message.
	 * 
	 * <p>If {@code takeScreenCapture} is {@code true}, than captures the
	 * current window and saves to a PNG file.
	 * 
	 * <p>Log level: INFO
	 * 
	 * @param message   the message to display when passing the test
	 * @param takeScreenCapture set to {@code true} if want to take a screen 
	 *                          capture, otherwise {@code false}
	 * @throws Exception 
	 */
	public static void passTest(String message, boolean takeScreenCapture)  {
		String link = "";
		try{
			if (takeScreenCapture) {
				link = Utils.takeScreenshot(Selenium.driver, sTestCaseName);
				if (link == null)
					link = "";

				AdvanceReporting.getTest().pass(message , MediaEntityBuilder.createScreenCaptureFromPath(link ).build());
			}
			else{
				Log.info("PASSED - "+ message + " " + link);
				AdvanceReporting.getTest().pass(message);
			}
		}
		catch(Exception e){
			Log.error("Exception:"+e.getMessage());
		}
	}

	/*
	 * #######################################################################################
	 * ##                           driver Driver Library                                 ##
	 * #######################################################################################
	 */


	/*
	 * type(), wrapper method for selenium type command
	 */

	public static void type(String sLocator, String sValue) 
	{
		String sObjectName = sLocator.substring(sLocator.lastIndexOf('.') + 1);
		type(sObjectName, sLocator, sValue);
	}


	public static void type(String sObjectName, String sLocator, String sValue) 	    
	{	
		type(sObjectName, sLocator, sValue, true) ;
		//		 	try
		//		 	{	
		//				wElement = getWebElement(sLocator,sObjectName);
		//				if (wElement != null)
		//				{
		//					Log.debug("Type event is occuring at " + sObjectName);	 
		//					wElement.clear();
		//		    		wElement.sendKeys(sValue);
		//		    		
		//		    		if (wElement.getAttribute("value").equalsIgnoreCase(sValue))
		//			    	Log.info("Type event has been succeeded at " + sObjectName);
		//		    		else
		//		    		Log.error("Type event has not been succeeded at " + sObjectName);
		//				}
		//				else
		//				{
		//					Log.error(sObjectName + " element is not present");
		//				}
		//		    }
		//			catch(Exception ex)
		//		    {
		//		    	Log.error("Exception in type():" + ex.getMessage());
		//		   	}
	}

	public static void type(String sObjectName, String sLocator, String sValue, boolean bValidateType) 	    
	{	    
		try
		{	
			wElement = getWebElement(sLocator,sObjectName);
			if (wElement != null)
			{
				Log.debug("Type event is occuring at " + sObjectName);	 
				wElement.clear();			
				wElement.sendKeys(sValue);
				if (bValidateType){
					String textValue=wElement.getAttribute("value");
					textValue=textValue.replace("(", "").replace(")", "").replace("-", "").replace(" ", "").replace("_", "");
					if (textValue.equalsIgnoreCase(sValue))
						Log.info("Type event has been succeeded at " + sObjectName);
					else
						Log.error("Type event has not been succeeded at " + sObjectName);
				}
			}
			else
			{
				Log.error(sObjectName + " element is not present");
			}
		}
		catch(Exception ex)
		{
			Log.error("Exception in type():" + ex.getMessage());
		}
	}


	public static void typeKey(String sObjectName, String sLocator, Keys sValue) 	    
	{	    
		try
		{	
			wElement = getWebElement(sLocator,sObjectName);
			if (wElement != null)
			{
				Log.debug("Type event is occuring at " + sObjectName);	 

				wElement.sendKeys(sValue);

			}
			else
			{
				Log.error(sObjectName + " element is not present");
			}
		}
		catch(Exception ex)
		{
			Log.error("Exception in type():" + ex.getMessage());
		}
	}  
	/*
	 * click(), wrapper method for selenium click command
	 */

	public static void click(String sObjectName, String sLocator) 
	{
		try
		{	
			Selenium.driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			wElement = getWebElement(sLocator,sObjectName);
			if (wElement!=null)
			{
				Log.debug("Click event is occuring at " + sObjectName);	


				wElement.click();
				Log.info("Click event has been succeeded at " + sObjectName);
			}
			else
			{
				Log.error(sObjectName + " element is not present");
			}
		}
		catch(Exception ex)
		{
			try{
				JavascriptExecutor executor = (JavascriptExecutor)Selenium.driver;
				executor.executeScript("arguments[0].click()", wElement);
				Log.info("Click event has been succeeded at " + sObjectName);
			}
			catch(Exception exp){
				Log.error("Exception in type():" + exp.getMessage());
				exp.printStackTrace();
			}
		}
	}


	
	

	/*
	 * isElementPresent(), wrapper method for selenium isElementPresent command
	 */

	public static boolean isElementPresent(String sLocator) 
	{
		String sObjectName = sLocator.substring(sLocator.lastIndexOf('.') + 1);
		return isElementPresent(sObjectName, sLocator) ;
	}

	public static boolean isElementPresent(String sObjectName,String sLocator) 	   
	{
		boolean sElementPresent=false;
		try
		{
			wElement = getWebElement(sLocator,sObjectName);   
			if(isElePresent)
			{
				sElementPresent=true;
				Log.info(sObjectName + " element is present");	    	
			}  
			else
			{
				Log.error(sObjectName + " element is not present");
			}
		}
		catch(Exception ex)
		{
			Log.error("Exception in isElementPrfesent():" + ex.getMessage());
		}
		return sElementPresent;
	}

	public static boolean isElementPresent(String sObjectName,String sLocator, boolean CheckVisible) 	   
	{
		boolean sElementPresent=false;
		try
		{
			if (CheckVisible)
				wElement = getWebElement(sLocator,sObjectName);  
			else
				wElement = getWebElement(sLocator,sObjectName,CheckVisible);
			if(isElePresent)
			{
				sElementPresent=true;
				Log.info(sObjectName + " element is present");	    	
			}  
			else
			{
				Log.error(sObjectName + " element is not present");
			}
		}
		catch(Exception ex)
		{
			Log.error("Exception in isElementPrfesent():" + ex.getMessage());
		}
		return sElementPresent;
	}

	/*
	 * isElementEnabled().... method to check, whether element is enabled or disabled
	 */

	public static boolean isElementEnabled(String sObjectName,String sLocator)    
	{
		boolean sElementPresent=false;
		try
		{
			wElement = getWebElement(sLocator,sObjectName);   
			if(wElement.isEnabled())
			{
				sElementPresent=true;
				Log.info(sObjectName + " element is enabled");	    	
			}  
			else
			{
				Log.error(sObjectName + " element is disabled");
			}
		}
		catch(Exception ex)
		{
			Log.error("Exception in isElementEnabled():" + ex.getMessage());
		}
		return sElementPresent;
	}

	/*
	 * getWebElement(), method for getting the webelement
	 */

	public static WebElement getWebElement(String sLocator,String sObjectName)
	{
		WebElement wElement=getWebElement(sLocator, sObjectName, true);

		return wElement;		
	}


	public static WebElement getWebElement(String sLocator,String sObjectName, boolean bExistance)
	{


		waiting = new WebDriverWait(driver, 10, 20);
		String sLocatorVal[] = new String[2];
		try
		{										
			if (!bExistance){				

				if (sLocator.contains("=")) 	
				{
					if (!sLocator.toUpperCase().contains("XPATH"))
						sLocatorVal = sLocator.split("=");

					if (sLocator.toUpperCase().contains("XPATH"))
					{
						System.out.println("********xpath=" + sObjectName);

						wElement = waiting.until(ExpectedConditions.elementToBeClickable(By.xpath(sLocator.substring(sLocator.indexOf("=")+1))));

						//wElement = waitForElement(driver,sLocatorVal[1].trim()); 				
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("ID"))
					{
						System.out.println("********Id= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.elementToBeClickable(By.id(sLocatorVal[1])));
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("NAME"))
					{
						System.out.println("********Name= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.elementToBeClickable(By.name(sLocatorVal[1])));
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("TAG"))
					{
						System.out.println("********Tag= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.elementToBeClickable(By.tagName(sLocatorVal[1])));
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("CLASS"))
					{
						System.out.println("********Tag= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.elementToBeClickable(By.tagName(sLocatorVal[1])));
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("LINKTEXT"))
					{
						System.out.println("********Tag= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(sLocatorVal[1])));
						isElePresent = true;
					}


				}
			}
			else{	

				if (sLocator.contains("="))	
				{
					if (!sLocator.toUpperCase().contains("XPATH"))
						sLocatorVal = sLocator.split("=");

					if (sLocator.toUpperCase().contains("XPATH"))
					{
						System.out.println("********xpath=" + sObjectName);

						wElement = waiting.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sLocator.substring(sLocator.indexOf("=")+1))));
						//wElement = waitForElement(driver,sLocatorVal[1].trim()); 				
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("ID"))
					{
						System.out.println("********Id= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.visibilityOfElementLocated(By.id(sLocatorVal[1])));
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("NAME"))
					{
						System.out.println("********Name= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.visibilityOfElementLocated(By.name(sLocatorVal[1])));
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("TAG"))
					{
						System.out.println("********Tag= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.visibilityOfElementLocated(By.tagName(sLocatorVal[1])));
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("CLASS"))
					{
						System.out.println("********Tag= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.visibilityOfElementLocated(By.tagName(sLocatorVal[1])));
						isElePresent = true;
					}
					else if (sLocatorVal[0].toUpperCase().equals("LINKTEXT"))
					{
						System.out.println("********Tag= " + sLocatorVal[1].trim());
						wElement = waiting.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(sLocatorVal[1])));
						isElePresent = true;
					}
				}

			}
		}

		catch (NoSuchElementException e)
		{
			Log.error(sObjectName+" Nosuch element exits");		    		    	
		}
		return wElement;


	}
	/*
	 * getWebElement(), method for getting the list of webelements
	 */



	/*************
	 * Method to swtich iframe 
	 *************/
	public static void switchToiFrames(String sLocator,String sObject )
	{
		try
		{ //getFrameAttributes("iframe");
			driver.switchTo().frame(getWebElement(sLocator, sObject));
			Log.info("Switch to "+sObject +" successfully");
		}
		catch(Exception ex)
		{
			Log.error("Exception in switchToFrames() :" + ex.getMessage());
		}	
	}


	/*
	 * getFrameAttributes(), method for getting the Frame attributes
	 */
	public static void getFrameAttributes(String sFrame)
	{
		List<WebElement> element = driver.findElements(By.tagName(sFrame));
		System.out.println("Number of frames in a page :" + element.size());
		for(WebElement el : element)
		{
			System.out.println("Frame Id is :" + el.getAttribute("id"));
			System.out.println("Frame name is :" + el.getAttribute("name"));
		}
	}


	/* 
	 * This method is to get the Alert popup 
	 */
	public static boolean getAlert() throws InterruptedException 
	{

		boolean presentFlag = false;

		try 
		{
			// Check the presence of alert
			Alert alert = driver.switchTo().alert();

			// Alert present; set the flag
			presentFlag = true;	       
			System.out.println(alert.getText());
			Log.info(alert.getText());

			// if present consume the alert
			alert.accept();

		}
		catch (NoAlertPresentException ex) {
			// Alert not present
			ex.printStackTrace();
		}

		return presentFlag;

	}

	





	/**
	 * Wait for the element to be present in the DOM, and displayed on the page. 
	 * And returns the first WebElement using the given method.
	 * @return WebElement        the first WebElement using the given method, or null (if the timeout is reached)
	 */
	public static WebElement waitForElement(WebDriver driver, String sLocator)
	{
		try{ 

			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); //nullify implicitlyWait()                      
			WebDriverWait wait = new WebDriverWait(driver,10 ,100); 
			wElement =  wait.until(ExpectedConditions.visibilityOf(Selenium.getWebElement(sLocator, "")));

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //reset implicitlyWait
			return wElement; //return the element        
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null; 
	}


	/**
	 * Validates the Object as well as its text
	 * @param ObjectName 			name of the object
	 * @param sLocator 				valid locator
	 * @param SubString				a text in the element to validate
	 * @param validateTextFlag		true-if the text needs to e validated otherwise put false
	 * @return a boolean value for the validation
	 **/
	public static boolean  ValidateObjectAndText (String ObjectName, String sLocator, String SubString, boolean validateTextFlag)
	{
		//String SubString,MainString;
		boolean BoolRes=false;
		String MainString;

		//Validate Object
		try
		{
			if (Selenium.isElementPresent(ObjectName, sLocator,true))
			{
				Reporter.log(ObjectName + " is Present on the page.");
				Selenium.passTest(ObjectName + " is Present on the page.");
				BoolRes=true;

				//Validate text
				if (validateTextFlag)
				{	
					MainString=Selenium.getWebElement(sLocator, ObjectName,true).getText();//getAttribute("name");

					String LSubString=SubString.toLowerCase();
					String LMainString=MainString.toLowerCase();
					if (LMainString.contains(LSubString)){

						Reporter.log(ObjectName + " having value : '"+ MainString + "' is validated on the page.");
						Log.info(ObjectName + " having value :'"+ MainString + "' is validated on the page.");
						BoolRes=true;
					}
					else{
						Reporter.log( ObjectName + " having value :'"+ MainString + "' is Not validated with text :" + SubString + ".");
						Log.error(ObjectName + " having text :'"+ MainString + "' is Not validated with text :" + SubString+ ".");
						BoolRes=false;
					}	
				}

			}
			else
			{
				Reporter.log(ObjectName + " is NOT Present on the page.");
				Log.error(ObjectName + " is NOT Present on the page.");
				BoolRes=false;
			}

		}
		catch(Exception e)
		{
			Log.error("Failed to validate thye object" + e.getMessage() );
			Reporter.log("Failed to validate thye object" + ObjectName );
			BoolRes=false;
		}

		return BoolRes;
	}

	

	public static void handleBrowserPopUp(String sOptions){
		//Accept the browser Message as Yes
		if (sOptions.equalsIgnoreCase("Ok"))
			driver.switchTo().alert().accept();

		else if (sOptions.equalsIgnoreCase("Cancel"))
			driver.switchTo().alert().dismiss();

	}



	public static boolean isAlertPresent() 
	{ 
		try 
		{ 
			driver.switchTo().alert(); 
			return true; 
		}   // try 
		catch (NoAlertPresentException Ex) 
		{ 
			return false; 
		}   // catch 
	}

	/**
	 * Wait for page to load 
	 * 
	 * **/

	/*
	 * public void waitForPageLoad() { try ( WebDriverWait wait = new
	 * WebDriverWait(driver,10 ,100); wElement = wait.until(((JavascriptExecutor)
	 * driver).executeScript("return document.readyState").equals("complete")); wait
	 * wait = new WebDriverWait(driver, 30) waiting.until(((JavascriptExecutor)
	 * driver).executeScript("return document.readyState").equals("complete"));
	 * 
	 * )
	 * 
	 * catch (InterruptedException ex) {
	 * 
	 * 
	 * }
	 */

	
	}




