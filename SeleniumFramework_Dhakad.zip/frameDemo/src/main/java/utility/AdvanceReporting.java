package utility;

import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;

public class AdvanceReporting {
	public static ExtentReports reports;
	public static ExtentHtmlReporter htmlReporter;
	private static ExtentTest test; 
	

	public static ExtentReports getReports() {
		return reports;
	}

	public static void setReports(ExtentReports reports) {
		AdvanceReporting.reports = reports;
	}


	public static ExtentTest getTest(){
		return test;
	}
	
	public static void setTest(ExtentTest eTest){
		test=eTest;
	}
	
	
     
}
