
package utility;

import java.io.File;

/**
 * Store constants used across the project
 * @author ShailendraDhakad
 */
public class Constant {
	  
	    public static final String TestData_File = "E://Resources//TestData//pepperfry//pepperfry_testData.xlsx";
		public static final String Path_ScreenShot = "C:" + File.separator + "Temp"  + File.separator + "pepperfry_results" + File.separator + "Screenshots" + File.separator ;
														//C:\Temp\pepperfry_results\Screenshots\
		public static final String Credential_File = "E://Resources//Credentials.xml";
		public static final String Applications_URL_File = "E://Resources//Application_url_Config.xlsx";

	}

