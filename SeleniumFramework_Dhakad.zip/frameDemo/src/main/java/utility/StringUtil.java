
package utility;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Handles string manipulation 
 * 
 * @author ShailendraDhakad
 */
public class StringUtil {
    
	 
	 public static String getTimeStamp(){
		 new java.util.Date();
		 String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		 return timeStamp;

	 }
	 

	
}
	

