
package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;


public class ExcelUtils {
	
	private static XSSFWorkbook ExcelWBook;
	private static XSSFSheet ExcelWSheet;
	private static XSSFCell Cell;

	public static Map<String, String> ReadExcelRowByIndexValue(String FileName, String SheetName, String IndexValue) {
		Log.info(
				"Reading Excel Data from file:" + FileName + " Sheet:" + SheetName + " With Index value:" + IndexValue);
		Map<Integer, List<String>> data = new HashMap<Integer, List<String>>();
		Map<String, String> dictionary = new HashMap<String, String>();
		try {
			FileInputStream inputStream = new FileInputStream(new File(FileName));
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet firstSheet = workbook.getSheet(SheetName);
			Iterator<Row> iterator = firstSheet.iterator();
			int rowCnt = 0;
			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				List<String> obj = new ArrayList<String>();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					String cellobj = cell.toString();
					if (cellobj.equals(" ")) {
						obj.add("");
					} else if (cellobj.equals(null)) {
						obj.add("");
					} else {
						obj.add(cell.toString());
					}

				}

				data.put(rowCnt, obj);
				rowCnt++;

			}
			workbook.close();
			String RowData = null;

			String Columns = data.get(0).toString();
			for (int i = 1; i < data.size(); i++) {
				if (data.get(i).toString().contains(IndexValue)) {
					RowData = data.get(i).toString();
					break;
				}
			}

			String[] ColumnsNames = Columns.replace("[", "").replace("]", "").split(",");
			String[] ColumnsValues = RowData.replace("[", "").replace("]", "").split(",");

			for (int j = 0; j < ColumnsNames.length; j++) {
				dictionary.put(ColumnsNames[j].trim(), ColumnsValues[j].trim());
			}

		} catch (Exception e) {

			Log.error("Exception occured while reading Excel Data. Exception:" + e.getMessage());

		}
		return dictionary;
	}

	// This method is to set the File path and to open the Excel file
	// Pass Excel Path and SheetName as Arguments to this method
	public static void setExcelFile(String Path, String SheetName) throws Exception {
		FileInputStream ExcelFile = new FileInputStream(Path);
		ExcelWBook = new XSSFWorkbook(ExcelFile);
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
	}

	// This method is to read the test data from the Excel cell
	// In this we are passing parameters/arguments as Row Num and Col Num
	public static String getCellData(int RowNum, int ColNum) throws Exception {
		Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
		String CellData = "";
		// Cell.get
		CellData = Cell.getStringCellValue();
		return CellData;
	}

	// writing to the cell object
	public static void setCellData(String data, int RowNum, int ColNum) throws Exception {
		try {
			XSSFRow Row = ExcelWSheet.getRow(RowNum);
			Cell = Row.getCell(ColNum);
			if (Cell == null) { // Cell was never used
				Cell = Row.createCell(ColNum);
				Cell.setCellValue(data);
			} else {
				Cell.setCellValue(data);
			}
		} catch (Exception e) {
			throw (e);
		}
	}

	public static void saveFile(String Path) throws IOException {
		try {
			FileOutputStream fileOut = new FileOutputStream(Path);
			ExcelWBook.write(fileOut);
			fileOut.close();
		} catch (IOException e) {
			throw (e);
		}
	}

}
