package appModules;

import org.testng.Reporter;

import utility.AdvanceReporting;
import utility.Log;
import utility.Selenium;
import utility.Utils;

public class userRegisterPage {

	public static void toRegisterPage() {
		// wait for login link to be visible

		try {
			Selenium.waitForElement(Selenium.driver, pageObjects.userRegisterPage.Register);
			Selenium.click("Register Link", pageObjects.userRegisterPage.Register);

			Selenium.waitForElement(Selenium.driver, pageObjects.userRegisterPage.AlertAd);
			Selenium.switchToiFrames(pageObjects.userRegisterPage.AlertAd, "Alter AD");
			Selenium.click("AdClose", pageObjects.userRegisterPage.Adclose);
			Selenium.driver.switchTo().defaultContent();
		} finally {
			userRegisterPage.isRegistrationPage();
		}

	}

	public static boolean isRegistrationPage() {

		boolean sResult = false;
		String newCustText = Selenium.getWebElement(pageObjects.userRegisterPage.newCusText, "new Customer Text")
				.getText();
		if (newCustText.contains("New Customer")) {

			Log.info("Registration page launched successfully");
			Reporter.log("Registration page launched successfully");
			sResult = true;
		} else {
			Log.info("failed, Registration page on launced ");
			Reporter.log("failed, Registration page on launced");
			Selenium.failTest("Failed to launch registration page ", true);
		}

		return sResult;
	}

	public static void passUserDetails(String email, String mobile, String fname, String lname, String pwd)
			throws Exception {

		try {
			Selenium.type("email ID", pageObjects.userRegisterPage.emailID, email);
			Selenium.type("mobile No. ", pageObjects.userRegisterPage.mobileID, mobile);
			Selenium.type("firstName ", pageObjects.userRegisterPage.firstnameID, fname);
			Selenium.type("lastName ", pageObjects.userRegisterPage.lastnameID, lname);
			Selenium.type("password ", pageObjects.userRegisterPage.passwordID, pwd);
			Selenium.click("genderRadio", pageObjects.userRegisterPage.genderRadio);
			Selenium.click("signUp button", pageObjects.userRegisterPage.signupID);
			// Selenium.driver.switchTo().defaultContent();
		} finally {
			userRegisterPage.isRegistrationSuccessfull();
		}

	}

	public static void isRegistrationSuccessfull() throws Exception {

		if (Selenium.isElementPresent("popUp after registration", pageObjects.userRegisterPage.popUpAfterRegistration
				)) {
			Log.info("Registration is successfully completed");
			Reporter.log("Registration is successfully completed");
			Selenium.passTest("Registraion completed", true);
		} else if (Selenium.isElementPresent("duplicate emailErrorMsg",
				pageObjects.userRegisterPage.duplicateEmailErrorMsg)) {
			Log.error("Duplicate email entered");
			Reporter.log("Duplicate email entered");
			Selenium.failTest("Duplicate email entered", true);
			//AdvanceReporting.getTest().addScreenCaptureFromPath(Utils.takeScreenshot(Selenium.driver, Selenium.sTestCaseName));

		} else {

			String errorMsg = Selenium
					.getWebElement(pageObjects.userRegisterPage.invalidFieldvalueMsg, "inValidFieldValueMsg").getText();

			if (errorMsg.contains("Please correct the fields marked in red below")) {
				Log.error("invalid test data");
				Reporter.log("invalid test data");
				Selenium.failTest("invalid test data", true);
			}
			

		}
	}
	
}
