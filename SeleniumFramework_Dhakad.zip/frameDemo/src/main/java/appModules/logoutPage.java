package appModules;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import utility.Log;
import utility.Selenium;

public class logoutPage {




	/**Page Methods
	 * @throws InterruptedException */
	public static void logout() throws InterruptedException {

		Actions act = new Actions(Selenium.driver);
		Log.info("Searching for logout link");
		try {
		act.moveToElement(Selenium.getWebElement(pageObjects.WebElements.LoginBlock, "LoginBlock")).perform();
		act.moveToElement(Selenium.getWebElement(pageObjects.WebElements.logOutLink, "Logout link")).click().build().perform();
		}
		finally {
		
		Thread.sleep(1000);
		logoutPage.isLogoutSuccess();
		}
		

	}

	public static boolean isLogoutSuccess() {
		
		  boolean sResult = false; 
		  
		  Log.info("Varifing--> user is successfully logged out from application");
		
		Selenium.waitForElement(Selenium.driver, pageObjects.WebElements.LoginButton);
		if (Selenium.ValidateObjectAndText("Login Button", pageObjects.WebElements.LoginButton, "Login", true))
			{
			sResult =true;
			Log.info("User is successfully Logged Out");
			Reporter.log("User is successfully Logged Out");
			
			}
		else {
			Log.info("User is successfully Logged Out");
			Reporter.log("User is successfully Logged Out");
			Selenium.failTest("Logout failed ", true);
		}
		return sResult;
		
	}

}


