package appModules;

import org.testng.Reporter;
import utility.Constant;
import utility.Log;
import utility.Selenium;
import utility.XMLUtil;

public class loginPage {

	/** Page Methods */

	
	  
	  public static boolean isHomePage () {
	  
	  boolean sResult = false; 
	  
	  String Title = Selenium.driver.getTitle();
	
	  if(Title.contains("Online Furniture Shopping Store:")){
		  sResult =true;
	  Reporter.log("Application is at Home Page");
	  Selenium.passTest("Application is at Home Page"); } 
	  else{
	  Reporter.log("Application is not at Home Page");
	  Selenium.failTest("Application is Not at Home Page"); } 
	  
	  return sResult;
	  
	  }
	 
	public static void login() throws InterruptedException {

		String user = XMLUtil.getXMLValue(Constant.Credential_File, "//Credentials/QA/Project/pepperFry/UserName");
		String pass = XMLUtil.getXMLValue(Constant.Credential_File, "//Credentials/QA/Project/pepperFry/Password");
		Log.info(pageObjects.WebElements.addPopUp);
		Selenium.waitForElement(Selenium.driver, pageObjects.WebElements.addPopUp);
		Selenium.switchToiFrames(pageObjects.WebElements.addPopUp, "popUp");
		// Selenium.driver.switchTo().frame(Selenium.getWebElement(pageObjects.WebElements.addPopUp,
		// "AddPOP"));
		Selenium.click("CloseAdvertisment", pageObjects.WebElements.closeAddPopUp);
		Thread.sleep(1000);
		Selenium.driver.switchTo().defaultContent();
		try {
			Selenium.click("Login Button", pageObjects.WebElements.LoginButton);
		} finally {
			Selenium.type(pageObjects.WebElements.userName, user);
			Selenium.type(pageObjects.WebElements.password, pass);
			Selenium.click("login Submit Button", pageObjects.WebElements.logSubmit);
		}

		if (Selenium.isElementPresent("LoginLink", pageObjects.WebElements.inValidEmail_Password)) {

			Log.debug("Login is Failed--> inValid Email or Password Entered");
			Reporter.log("Logging into Application is failed--> inValid Email or Password Entered");
			Selenium.failTest("Logging into Application is failed--> inValid Email or Password Entered", true);

		} else if (Selenium.ValidateObjectAndText("Varification After login", pageObjects.WebElements.afterLoginHi,
				"Hi", false)) {
			Log.info("Login is sucessfull");
			Reporter.log("Logged into Application successfully");
			Selenium.passTest("Logging into Application is passed", true);

		} else {
			Log.info("Login is failed");
			Reporter.log("Logged into Application failed");
			Selenium.failTest("Logging into Application failed", true);

		}
	}


}
