package pageObjects;



public class userRegisterPage {

	/**Variables*/
	//String baseURL = "https://www.pepperfry.com/ ";

	/**Web Elements*/

	public static final String Register = "xpath=//a[@id='registerPopupLink']//b[contains(text(),'Register')]"; 
	public static final String emailID ="name=email";
	public static final String mobileID="name=mobile";
	public static final String firstnameID ="name=firstname";
	public static final String lastnameID ="name=lastname";
	public static final String passwordID ="id=password1-mreg";
	public static final String genderRadio ="xpath=//span[contains(text(),'Male')]";
	public static final String signupID ="id=formSubmit-popup_reg_form";
	public static final String AlertAd ="xpath=//iframe[starts-with(@name,'notification-frame-')]";
	public static final String Adclose ="xpath=//span[@class='wewidgeticon we_close icon-large']";
	public static final String newCusText="xpath=//*[@id=\"signinupPopupBox\"]/div/div[1]/div[1]/h5";
	public static final String invalidFieldvalueMsg ="xpath=//*[@id=\"errormsgTop\"]";
	public static final String  popUpAfterRegistration="xpath=//*[@id=\"offerPopups\"]/div/img";
	public static final String duplicateEmailErrorMsg = "xpath=//*[@class=\"error-msg pf-text-red font-13 pf-semi-bold-text\"and @id=\"email\"]";
	public static final String duplicateMobErrorMsg = "xpath=//*[@class=\"error-msg pf-text-red font-13 pf-semi-bold-text\"and @id=\"mobile\"]";
	
	

	
	
	/*
	 * static By Register=By.xpath(
	 * "//a[@id='registerPopupLink']//b[contains(text(),'Register')]"); static By
	 * emailID = By.name("email"); static By mobileID = By.name("mobile"); static By
	 * firstnameID = By.name("firstname"); static By lastnameID =
	 * By.name("lastname"); static By passwordID = By.id("password1-mreg"); static
	 * By genderRadio = By.xpath("//span[contains(text(),'Male')]"); static By
	 * signupID = By.id("formSubmit-popup_reg_form"); static By
	 * AlertAd=By.xpath("//iframe[starts-with(@name,'notification-frame-')]");
	 * static By
	 * Adclose=By.xpath("//span[@class='wewidgeticon we_close icon-large']");
	 */


}


