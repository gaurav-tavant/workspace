package pageObjects;

public class WebElements {

	/**Variables*/
	//String baseURL = "https://www.pepperfry.com/ ";

	/**Web Elements*/

	public static final String Login = "linkText=login"; 
	public static final String LoginButton = "xpath=//*[@id=\"loginPopupLink\"]/b";
	public static final String LoginBlock ="xpath=//li[@class='login-block']";
	public static final String addPopUp = "xpath=//iframe[starts-with(@name,'notification-frame-')]";
	public static final String closeAddPopUp = "xpath=//span[@class='wewidgeticon we_close icon-large']";
	public static final String userName = "name=user[new]";
	public static final String logSubmit = "name=logSubmit";
	public static final String password = "name=password";
	public static final String dept = "xpath=//*[@id=\"menu_wrapper\"]/ul/li[1]/a/span";
	public static final String wallartLink ="linkText=Wall Art";
	public static final String wildLifeLink = "linkText=Wild life";
	public static final String floralLink = "linkText=Floral";
	public static final String sortByDropDown="xpath=//*[@id=\"curSortType\"]";
	public static final String PriceLowToHigh ="xpath=//*[@id=\"sortBY\"]/li[3]/a";
	public static final String searchedProductList ="xpath=//div[@id='productView']/div/div/div/div"; 
	public static final String wildArtsearchedProdNames ="xpath=//a[@class='clip-prd-dtl']"; 
	public static final String wildArtsearchedProdPrices = "xpath=//div[@id='productView']/div/div/div/div/div/div[5]/div/span[1]"; 
	public static final String loginLogoffBlock = "xpath=//li[@class='login-block']";
	public static final String logOutLink ="linkText=Logout";
	public static final String inValidEmail_Password = "xpath=//*[@id=\"login_popup_login_form\"]/div[1]";
	public static final String afterLoginHi ="xpath=//*[@id=\"page\"]/header/div[3]/div/div[1]/div/ul/li[7]/div[2]/a";
	
	
	public static final String furniture = "linkText=Furniture";
	public static final String sofaSet = "linkText=Sofa Sets";
	public static final String registerPopUp ="xpath=//*[@id=\"signinupPopupBox\"]/div";
	public static final String registerPopUpClose = "xpath=//*[@id=\"signinupPopupBox\"]/a";
	public static final String furSearchedProdNames = "xpath=//div[@class='clip-lstvw-prdcnt']";
	public static final String furSearchedProdPrices = "xpath=//span[@class='clip-offr-price ']";
	
	
	
	
	
	
	/*
	 * public static By closeAddPopUp =
	 * By.xpath("//span[@class='wewidgeticon we_close icon-large']"); public static
	 * By userName = By.name("user[new]"); public static By password
	 * =By.name("password"); public static By logSubmit = By.name("logSubmit");
	 * public static By dept = By.className("hd-meta-dept"); public static
	 * BywallartLink = By.linkText("Wall Art"); public static By wildLifeLink
	 * =By.linkText("Wild life"); public static By sortByDropDown
	 * =By.xpath("//*[@id=\"curSortType\"]"); public static By PriceLowToHigh
	 * =By.xpath("//*[@id=\"sortBY\"]/li[3]/a"); public static By
	 * searchedProductList= By.xpath("//div[@id='productView']/div/div/div/div");
	 * public static By searchedProductNames =
	 * By.xpath("//a[@class='clip-prd-dtl']"); public static By
	 * searchedProductPrices =
	 * By.xpath("//div[@id='productView']/div/div/div/div/div/div[5]/div/span[1]");
	 * public static By loginLogoffBlock = By.xpath("//li[@class='login-block']");
	 * public static By logOutLink = By.linkText("Logout");
	 * 
	 * public static final String TEXT_USERNAME = "id=P101_USERNAME"; public static
	 * final String TEXT_PASSWORD = "id=P101_PASSWORD"; public static final String
	 * BUTTON_LOGIN =
	 * "xpath=//*[@id=\"apex_layout_328137400289283815\"]/tbody/tr[2]/td[3]/button/span";
	 * public static final String TEXT_MESSAGE =
	 * "xpath=//*[@id=\"R328209613792957559\"]/div[2]/div/div[2]/center/font";
	 * 
	 */

}


