package testCases;


import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import appModules.userRegisterPage;
import utility.AdvanceReporting;
import utility.BaseExtentReport;
import utility.Constant;
import utility.ExcelUtils;
import utility.Log;
import utility.Selenium;
import utility.Utils;

public class registration extends BaseExtentReport{

	public  WebDriver driver;
	Map<String, String> TestDatadictionary;
	
		
	@BeforeMethod
	  public void beforeMethod() throws Exception {
			
		  	DOMConfigurator.configure("log4j.xml");
		  	Selenium.sTestCaseName = Utils.getTestCaseName(this.toString());
		  	Log.startTestCase(Selenium.sTestCaseName);
		 	
			//Set Extent Reporter Object and Test Object
		 	test=extent.createTest(Utils.getTestCaseName(this.toString()));
		 	AdvanceReporting.setTest(test);
		 	
		 	Map<String, String> AppURLdictionary = ExcelUtils.ReadExcelRowByIndexValue(Constant.Applications_URL_File,"urlConfig","QA");
		 	driver = Selenium.openApplication(AppURLdictionary.get("URL"), "chrome");	
		 	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	  
	  @Test
	  public void test() throws Exception {
		  Map<String, String> TestDatadictionary = ExcelUtils.ReadExcelRowByIndexValue(Constant.TestData_File,"pepperFry","Register");
		  
		  userRegisterPage.toRegisterPage();
		  userRegisterPage.passUserDetails(
				  TestDatadictionary.get("email"), TestDatadictionary.get("mobile"), TestDatadictionary.get("fname"), 
				  TestDatadictionary.get("lname"), TestDatadictionary.get("pwd"));
		 
	
		}
	  @AfterMethod
	  public void afterMethod() {
		    // Printing beautiful logs to end the test case
		    Log.endTestCase(Selenium.sTestCaseName);
		    // Closing the opened driver
	    driver.close();
		
       }
}
	


       

